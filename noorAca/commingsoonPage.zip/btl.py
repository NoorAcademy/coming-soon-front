#!/usr/bin/python2.7
#-*- coding: utf-8 -*-
# encoding : utf-8
#from urllib.request import urlopen
import urllib2
import bottle
import json
from pprint import pprint
import os
import jinja2
from jinja2 import Environment, FileSystemLoader
import xml.etree.ElementTree as ET
from pymongo import MongoClient as mongo

#from bottle import jinja2_view
#from bottle import jinja2_template as template
@bottle.route('/img/<filepath:path>')
def server_static(filepath):
    return bottle.static_file(filepath, root='./img/')
@bottle.route('/js/<filepath:path>')
def server_static(filepath):
    return bottle.static_file(filepath, root='./js/')
@bottle.route('/css/<filepath:path>')
def server_static(filepath):
    return bottle.static_file(filepath, root='./css/') 
@bottle.route('/fonts/<filepath:path>')
def server_static(filepath):
    return bottle.static_file(filepath, root='./fonts/')     
@bottle.route('/')
def p_p():
   return bottle.template('index.html')

    
bottle.run(port=8080 ,debug=True)
